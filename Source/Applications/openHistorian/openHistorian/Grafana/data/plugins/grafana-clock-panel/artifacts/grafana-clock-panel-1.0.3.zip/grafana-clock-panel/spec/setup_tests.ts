console.log = jest.fn();
console.error = jest.fn();
